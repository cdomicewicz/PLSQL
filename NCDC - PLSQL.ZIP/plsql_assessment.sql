
set echo off
set time on
set timing on
spool log_MyData.log

--------------------------------------------------------
--  File created - niedziela-lutego-14-2021   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table DOCUMENTS
--------------------------------------------------------

  CREATE TABLE "DOCUMENTS" 
   (	"DOCUMENT_ID" NUMBER, 
	"DOCUMENT_NAME" VARCHAR2(50 BYTE), 
	"DOCUMENT_DESCRIPTION" VARCHAR2(4000 BYTE), 
	"RECORD_TIMESTAMP" TIMESTAMP (6), 
	"TIMESTAMP_" TIMESTAMP (6), 
	"RECORD_USER_ID" VARCHAR2(50 BYTE), 
	"USER_ID" VARCHAR2(50 BYTE)
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;
REM INSERTING into DOCUMENTS
SET DEFINE OFF;
Insert into DOCUMENTS (DOCUMENT_ID,DOCUMENT_NAME,DOCUMENT_DESCRIPTION,RECORD_TIMESTAMP,TIMESTAMP_,RECORD_USER_ID,USER_ID) values ('1','My First Document','1x Important To Me',to_timestamp('21/02/14 12:42:49,437000000','RR/MM/DD HH24:MI:SSXFF'),to_timestamp('21/02/14 12:42:49,437000000','RR/MM/DD HH24:MI:SSXFF'),'HR by insert trigger','HR by insert trigger');
Insert into DOCUMENTS (DOCUMENT_ID,DOCUMENT_NAME,DOCUMENT_DESCRIPTION,RECORD_TIMESTAMP,TIMESTAMP_,RECORD_USER_ID,USER_ID) values ('2','My Updated Second Document','Simply Updated',to_timestamp('21/02/14 12:42:49,438000000','RR/MM/DD HH24:MI:SSXFF'),to_timestamp('21/02/14 12:42:49,439000000','RR/MM/DD HH24:MI:SSXFF'),'HR by insert trigger','HR by update trigger');
Insert into DOCUMENTS (DOCUMENT_ID,DOCUMENT_NAME,DOCUMENT_DESCRIPTION,RECORD_TIMESTAMP,TIMESTAMP_,RECORD_USER_ID,USER_ID) values ('3','My Third Document',null,to_timestamp('21/02/14 12:42:49,438000000','RR/MM/DD HH24:MI:SSXFF'),to_timestamp('21/02/14 12:42:49,438000000','RR/MM/DD HH24:MI:SSXFF'),'HR by insert trigger','HR by insert trigger');
Insert into DOCUMENTS (DOCUMENT_ID,DOCUMENT_NAME,DOCUMENT_DESCRIPTION,RECORD_TIMESTAMP,TIMESTAMP_,RECORD_USER_ID,USER_ID) values ('4','My Fourht Document','4x Important To Me',to_timestamp('21/02/14 12:42:49,438000000','RR/MM/DD HH24:MI:SSXFF'),to_timestamp('21/02/14 12:42:49,438000000','RR/MM/DD HH24:MI:SSXFF'),'HR by insert trigger','HR by insert trigger');
Insert into DOCUMENTS (DOCUMENT_ID,DOCUMENT_NAME,DOCUMENT_DESCRIPTION,RECORD_TIMESTAMP,TIMESTAMP_,RECORD_USER_ID,USER_ID) values ('5','My Fifth Document','5x Important To Me',to_timestamp('21/02/14 12:42:49,438000000','RR/MM/DD HH24:MI:SSXFF'),to_timestamp('21/02/14 12:42:49,438000000','RR/MM/DD HH24:MI:SSXFF'),'HR by insert trigger','HR by insert trigger');
Insert into DOCUMENTS (DOCUMENT_ID,DOCUMENT_NAME,DOCUMENT_DESCRIPTION,RECORD_TIMESTAMP,TIMESTAMP_,RECORD_USER_ID,USER_ID) values ('6','My Sixth Document','6x Important To Me',to_timestamp('21/02/14 12:42:49,438000000','RR/MM/DD HH24:MI:SSXFF'),to_timestamp('21/02/14 12:42:49,438000000','RR/MM/DD HH24:MI:SSXFF'),'HR by insert trigger','HR by insert trigger');
Insert into DOCUMENTS (DOCUMENT_ID,DOCUMENT_NAME,DOCUMENT_DESCRIPTION,RECORD_TIMESTAMP,TIMESTAMP_,RECORD_USER_ID,USER_ID) values ('7','My Seventh Document','7x Important To Me',to_timestamp('21/02/14 12:42:49,438000000','RR/MM/DD HH24:MI:SSXFF'),to_timestamp('21/02/14 12:42:49,438000000','RR/MM/DD HH24:MI:SSXFF'),'HR by insert trigger','HR by insert trigger');
Insert into DOCUMENTS (DOCUMENT_ID,DOCUMENT_NAME,DOCUMENT_DESCRIPTION,RECORD_TIMESTAMP,TIMESTAMP_,RECORD_USER_ID,USER_ID) values ('8','My Eight Document','8x Important To Me',to_timestamp('21/02/14 12:42:49,439000000','RR/MM/DD HH24:MI:SSXFF'),to_timestamp('21/02/14 12:42:49,439000000','RR/MM/DD HH24:MI:SSXFF'),'HR by insert trigger','HR by insert trigger');
Insert into DOCUMENTS (DOCUMENT_ID,DOCUMENT_NAME,DOCUMENT_DESCRIPTION,RECORD_TIMESTAMP,TIMESTAMP_,RECORD_USER_ID,USER_ID) values ('9','My Nineth Document','9x Important To Me',to_timestamp('21/02/14 12:42:49,439000000','RR/MM/DD HH24:MI:SSXFF'),to_timestamp('21/02/14 12:42:49,439000000','RR/MM/DD HH24:MI:SSXFF'),'HR by insert trigger','HR by insert trigger');
Insert into DOCUMENTS (DOCUMENT_ID,DOCUMENT_NAME,DOCUMENT_DESCRIPTION,RECORD_TIMESTAMP,TIMESTAMP_,RECORD_USER_ID,USER_ID) values ('10','My Tenth Document','10x Important To Me',to_timestamp('21/02/14 12:42:49,439000000','RR/MM/DD HH24:MI:SSXFF'),to_timestamp('21/02/14 12:42:49,439000000','RR/MM/DD HH24:MI:SSXFF'),'HR by insert trigger','HR by insert trigger');
Insert into DOCUMENTS (DOCUMENT_ID,DOCUMENT_NAME,DOCUMENT_DESCRIPTION,RECORD_TIMESTAMP,TIMESTAMP_,RECORD_USER_ID,USER_ID) values ('11','My Eleventh Document','11x Important To Me',to_timestamp('21/02/14 12:42:49,439000000','RR/MM/DD HH24:MI:SSXFF'),to_timestamp('21/02/14 12:42:49,439000000','RR/MM/DD HH24:MI:SSXFF'),'HR by insert trigger','HR by insert trigger');
--------------------------------------------------------
--  DDL for Trigger MY_TRIGGER
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE TRIGGER "MY_TRIGGER" 
FOR INSERT OR UPDATE OF document_id, document_name, document_description ON documents
COMPOUND TRIGGER

    TYPE t_documents_modified IS TABLE OF documents.document_id%TYPE INDEX BY PLS_INTEGER;
    v_inserted_documents_id t_documents_modified;
    v_updated_documents_id t_documents_modified; 
    v_new_document_id NUMBER;
    v_inserted_documents_counter NUMBER := 0;
    v_updated_documents_counter NUMBER :=0;
    v_user VARCHAR2(100):= USER;
    v_timestamp TIMESTAMP(3) WITH TIME ZONE NOT NULL := SYSTIMESTAMP;

    BEFORE EACH ROW IS
      BEGIN
            v_new_document_id := :NEW.document_id;
            IF inserting THEN
                v_inserted_documents_counter := v_inserted_documents_counter + 1;
                v_inserted_documents_id(v_inserted_documents_counter) := v_new_document_id;
            ELSE
                IF NOT v_updated_documents_id.EXISTS(v_new_document_id) THEN
                    v_updated_documents_counter := v_updated_documents_counter + 1;
                    v_updated_documents_id(v_updated_documents_counter) := v_new_document_id;
                END IF;
          END IF;
    END BEFORE EACH ROW;

    AFTER STATEMENT IS
        BEGIN   
        
            FOR i in 1 .. v_inserted_documents_id.count LOOP
                UPDATE documents
                SET record_timestamp = v_timestamp,
                timestamp_ = v_timestamp,
                record_user_id = v_user || ' by insert trigger',
                user_id = v_user || ' by insert trigger'
                WHERE document_id = v_inserted_documents_id(i);
                dbms_output.put_line('INSERT: Trigger fired! Fields: Record Timestamp and Record User ID have been updated!');
                
            END LOOP;
        
            FOR i in 1 .. v_updated_documents_id.count LOOP
                UPDATE documents
                SET timestamp_ = v_timestamp,
                user_id = v_user || ' by update trigger'
                WHERE document_id = v_updated_documents_id(i);
                dbms_output.put_line('UPDATE: Trigger fired! Fields: Timestamp and User ID have been updated!');
            END LOOP;
        
            --dbms_output.put_line(v_inserted_documents_counter || ' record(s) inserted in table.');
            --dbms_output.put_line(v_updated_documents_counter || ' record(s) updated in table.');
            
    END AFTER STATEMENT;
END;
/
ALTER TRIGGER "MY_TRIGGER" ENABLE;
--------------------------------------------------------
--  DDL for Trigger MY_TRIGGER
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE TRIGGER "MY_TRIGGER" 
FOR INSERT OR UPDATE OF document_id, document_name, document_description ON documents
COMPOUND TRIGGER

    TYPE t_documents_modified IS TABLE OF documents.document_id%TYPE INDEX BY PLS_INTEGER;
    v_inserted_documents_id t_documents_modified;
    v_updated_documents_id t_documents_modified; 
    v_new_document_id NUMBER;
    v_inserted_documents_counter NUMBER := 0;
    v_updated_documents_counter NUMBER :=0;
    v_user VARCHAR2(100):= USER;
    v_timestamp TIMESTAMP(3) WITH TIME ZONE NOT NULL := SYSTIMESTAMP;

    BEFORE EACH ROW IS
      BEGIN
            v_new_document_id := :NEW.document_id;
            IF inserting THEN
                v_inserted_documents_counter := v_inserted_documents_counter + 1;
                v_inserted_documents_id(v_inserted_documents_counter) := v_new_document_id;
            ELSE
                IF NOT v_updated_documents_id.EXISTS(v_new_document_id) THEN
                    v_updated_documents_counter := v_updated_documents_counter + 1;
                    v_updated_documents_id(v_updated_documents_counter) := v_new_document_id;
                END IF;
          END IF;
    END BEFORE EACH ROW;

    AFTER STATEMENT IS
        BEGIN   
        
            FOR i in 1 .. v_inserted_documents_id.count LOOP
                UPDATE documents
                SET record_timestamp = v_timestamp,
                timestamp_ = v_timestamp,
                record_user_id = v_user || ' by insert trigger',
                user_id = v_user || ' by insert trigger'
                WHERE document_id = v_inserted_documents_id(i);
                dbms_output.put_line('INSERT: Trigger fired! Fields: Record Timestamp and Record User ID have been updated!');
                
            END LOOP;
        
            FOR i in 1 .. v_updated_documents_id.count LOOP
                UPDATE documents
                SET timestamp_ = v_timestamp,
                user_id = v_user || ' by update trigger'
                WHERE document_id = v_updated_documents_id(i);
                dbms_output.put_line('UPDATE: Trigger fired! Fields: Timestamp and User ID have been updated!');
            END LOOP;
        
            --dbms_output.put_line(v_inserted_documents_counter || ' record(s) inserted in table.');
            --dbms_output.put_line(v_updated_documents_counter || ' record(s) updated in table.');
            
    END AFTER STATEMENT;
END;
/
ALTER TRIGGER "MY_TRIGGER" ENABLE;
--------------------------------------------------------
--  DDL for Procedure PRINT_DOCUMENTS
--------------------------------------------------------
set define off;

  CREATE OR REPLACE EDITIONABLE PROCEDURE "PRINT_DOCUMENTS" IS 
CURSOR C_CURSOR IS SELECT * FROM DOCUMENTS;  
BEGIN 

FOR R_DESC IN C_CURSOR LOOP
IF R_DESC.DOCUMENT_DESCRIPTION IS NOT NULL THEN 
  DBMS_OUTPUT.PUT_LINE(R_DESC.DOCUMENT_DESCRIPTION);
ELSE 
  DBMS_OUTPUT.PUT_LINE('No record');
END IF;
  END LOOP;
END PRINT_DOCUMENTS;


/
--------------------------------------------------------
--  DDL for Package MY_PACKAGE
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE PACKAGE "MY_PACKAGE" AS
     FUNCTION validate_pesel (
          pesel IN VARCHAR2
     ) RETURN BOOLEAN;

     PROCEDURE print_documents;

END my_package;


/
--------------------------------------------------------
--  DDL for Package TESTER_PCKG
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE PACKAGE "TESTER_PCKG" AS 
    --PROCEDURE create_table_documents;

     PROCEDURE create_single_entry (
          doc_id           NUMBER,
          doc_name         IN  VARCHAR2,
          doc_description  IN  VARCHAR2
     );

     PROCEDURE create_entries;

     PROCEDURE update_single_entry (
          doc_id           NUMBER,
          doc_name         IN  VARCHAR2,
          doc_description  IN  VARCHAR2
     );

     PROCEDURE update_table;

END tester_pckg;


/
--------------------------------------------------------
--  DDL for Package Body MY_PACKAGE
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE PACKAGE BODY "MY_PACKAGE" AS

  FUNCTION validate_pesel (pesel IN VARCHAR2) RETURN BOOLEAN AS
    TYPE T_WEIGHTS IS VARRAY(11) OF SIMPLE_INTEGER;
    --Coefficents to calculate control number
    vt_Weights t_weights := t_weights(1, 3, 7, 9, 1, 3, 7,9,1,3,1);
    v_status VARCHAR(30) := 'incorrect';
    vn_checksum SIMPLE_INTEGER := 0;
    v_num NUMBER;
    v_len NUMBER;

BEGIN
    /*Pesel has to have eleven characters. 
    When it's true if pesel cannot be coverted to a integer exception will be thrown. 
    There could be also a method to validate, characters, length etc. */

    v_num := TO_NUMBER(PESEL);
    v_len  := LENGTH(PESEL);

    IF v_len = 11 THEN
        FOR i IN 1..vt_Weights.COUNT
            LOOP
                --Control number is calculated here
                vn_checksum := vn_checksum + TO_NUMBER(SUBSTR( PESEL, i,1)) * vt_Weights(i);
            END LOOP;
        --If there is no reminder, control number is correct. In any other case function will return false
        IF MOD(vn_checksum, 10) = 0 THEN
          v_status := 'correct';
          DBMS_OUTPUT.PUT_LINE('Control number: ' || vn_checksum || '.');
          DBMS_OUTPUT.PUT_LINE('PESEL: ' || PESEL || ' is ' || v_status ||'.');
          RETURN TRUE;
        END IF;
          DBMS_OUTPUT.PUT_LINE('Control number: ' || vn_checksum || '.');
    ELSE
        DBMS_OUTPUT.PUT_LINE('PESEL: ' || PESEL || ' is ' || v_status || '.');
    RETURN FALSE;
    END IF;
    DBMS_OUTPUT.PUT_LINE('PESEL: ' || PESEL || ' is ' || v_status || '.');
  RETURN FALSE;
EXCEPTION
WHEN VALUE_ERROR THEN
  DBMS_OUTPUT.PUT_LINE('PESEL: ' || PESEL || ' is ' || v_status || '.');
  RETURN FALSE;
  END validate_pesel;

PROCEDURE print_documents IS
CURSOR C_CURSOR IS SELECT * FROM DOCUMENTS;  
BEGIN 
    FOR R_DESC IN C_CURSOR LOOP
        IF R_DESC.DOCUMENT_DESCRIPTION IS NOT NULL THEN 
          DBMS_OUTPUT.PUT_LINE(R_DESC.DOCUMENT_DESCRIPTION);
        ELSE 
          DBMS_OUTPUT.PUT_LINE('No Description');
        END IF;
    END LOOP;
  END print_documents;
END MY_PACKAGE;


/
--------------------------------------------------------
--  DDL for Package Body TESTER_PCKG
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE PACKAGE BODY "TESTER_PCKG" AS

     v_usr    VARCHAR2(30) := 'default';
     v_tstmp  TIMESTAMP(9) := to_timestamp('01-01-2000 00:00', 'MM-DD-YYYY HH24:MI:SS');

     PROCEDURE create_entries AS
     BEGIN
          DELETE FROM documents;
          create_single_entry(1, 'My First Document', '1x Important To Me');
          create_single_entry(2, 'My Second Document', '2x Important To Me');
          create_single_entry(3, 'My Third Document', NULL);
          create_single_entry(4, 'My Fourht Document', '4x Important To Me');
          create_single_entry(5, 'My Fifth Document', '5x Important To Me');
          create_single_entry(6, 'My Sixth Document', '6x Important To Me');
          create_single_entry(7, 'My Seventh Document', '7x Important To Me');
          create_single_entry(8, 'My Eight Document', '8x Important To Me');
          create_single_entry(9, 'My Nineth Document', '9x Important To Me');
          create_single_entry(10, 'My Tenth Document', '10x Important To Me');
     END create_entries;

    --Creation of single entry. Record Timestamp, Timestamp, Record User Id and User Id have default values
     PROCEDURE create_single_entry (
          doc_id           NUMBER,
          doc_name         IN  VARCHAR2,
          doc_description  IN  VARCHAR2
     ) AS
     BEGIN
          INSERT INTO documents (
               document_id,
               document_name,
               document_description,
               record_timestamp,
               timestamp_,
               record_user_id,
               user_id
          ) VALUES (
               doc_id,
               doc_name,
               doc_description,
               v_tstmp,
               v_tstmp,
               v_usr,
               v_usr
          );
     END create_single_entry;

     PROCEDURE update_table AS
     BEGIN
          update_single_entry(1, 'My Second Document', 'Again Important To Me');
     END update_table;

     PROCEDURE update_single_entry (
          doc_id           NUMBER,
          doc_name         IN  VARCHAR2,
          doc_description  IN  VARCHAR2
     ) AS
     BEGIN
          UPDATE documents
          SET
               document_id = doc_id,
               document_name = doc_name,
               document_description = doc_description
          WHERE
               document_id = doc_id;
     END;

END tester_pckg;


/
--------------------------------------------------------
--  Constraints for Table DOCUMENTS
--------------------------------------------------------

  ALTER TABLE "DOCUMENTS" MODIFY ("DOCUMENT_ID" NOT NULL ENABLE);
  ALTER TABLE "DOCUMENTS" MODIFY ("DOCUMENT_NAME" NOT NULL ENABLE);
  ALTER TABLE "DOCUMENTS" MODIFY ("RECORD_TIMESTAMP" NOT NULL ENABLE);
  ALTER TABLE "DOCUMENTS" MODIFY ("TIMESTAMP_" NOT NULL ENABLE);
  ALTER TABLE "DOCUMENTS" MODIFY ("RECORD_USER_ID" NOT NULL ENABLE);
  ALTER TABLE "DOCUMENTS" MODIFY ("USER_ID" NOT NULL ENABLE);

spool off