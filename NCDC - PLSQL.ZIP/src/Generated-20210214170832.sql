--------------------------------------------------------
--  File created - niedziela-lutego-14-2021   
--------------------------------------------------------
@C:\Users\cezary.domicewicz\Desktop\Database PLSQL export\13th_Export\Source files\TABLES\DOCUMENTS.sql
@C:\Users\cezary.domicewicz\Desktop\Database PLSQL export\13th_Export\Source files\DATA_TABLE\DOCUMENTS.sql
@C:\Users\cezary.domicewicz\Desktop\Database PLSQL export\13th_Export\Source files\TRIGGERS\MY_TRIGGER.sql
@C:\Users\cezary.domicewicz\Desktop\Database PLSQL export\13th_Export\Source files\TRIGGERS\MY_TRIGGER_1.sql
@C:\Users\cezary.domicewicz\Desktop\Database PLSQL export\13th_Export\Source files\PROCEDURES\PRINT_DOCUMENTS.sql
@C:\Users\cezary.domicewicz\Desktop\Database PLSQL export\13th_Export\Source files\PACKAGES\MY_PACKAGE.sql
@C:\Users\cezary.domicewicz\Desktop\Database PLSQL export\13th_Export\Source files\PACKAGES\TESTER_PCKG.sql
@C:\Users\cezary.domicewicz\Desktop\Database PLSQL export\13th_Export\Source files\PACKAGE_BODIES\MY_PACKAGE.sql
@C:\Users\cezary.domicewicz\Desktop\Database PLSQL export\13th_Export\Source files\PACKAGE_BODIES\TESTER_PCKG.sql
