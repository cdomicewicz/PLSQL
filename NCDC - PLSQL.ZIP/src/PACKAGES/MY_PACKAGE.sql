--------------------------------------------------------
--  DDL for Package MY_PACKAGE
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE PACKAGE "MY_PACKAGE" AS
     FUNCTION validate_pesel (
          pesel IN VARCHAR2
     ) RETURN BOOLEAN;

     PROCEDURE print_documents;

END my_package;



/
