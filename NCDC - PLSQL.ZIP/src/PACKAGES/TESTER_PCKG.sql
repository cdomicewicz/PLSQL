--------------------------------------------------------
--  DDL for Package TESTER_PCKG
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE PACKAGE "TESTER_PCKG" AS 
    --PROCEDURE create_table_documents;

     PROCEDURE create_single_entry (
          doc_id           NUMBER,
          doc_name         IN  VARCHAR2,
          doc_description  IN  VARCHAR2
     );

     PROCEDURE create_entries;

     PROCEDURE update_single_entry (
          doc_id           NUMBER,
          doc_name         IN  VARCHAR2,
          doc_description  IN  VARCHAR2
     );

     PROCEDURE update_table;

END tester_pckg;



/
