--------------------------------------------------------
--  DDL for Trigger MY_TRIGGER
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE TRIGGER "MY_TRIGGER" 
FOR INSERT OR UPDATE OF document_id, document_name, document_description ON documents
COMPOUND TRIGGER

    TYPE t_documents_modified IS TABLE OF documents.document_id%TYPE INDEX BY PLS_INTEGER;
    v_inserted_documents_id t_documents_modified;
    v_updated_documents_id t_documents_modified; 
    v_new_document_id NUMBER;
    v_inserted_documents_counter NUMBER := 0;
    v_updated_documents_counter NUMBER :=0;
    v_user VARCHAR2(100):= USER;
    v_timestamp TIMESTAMP(3) WITH TIME ZONE NOT NULL := SYSTIMESTAMP;

    BEFORE EACH ROW IS
      BEGIN
            v_new_document_id := :NEW.document_id;
            IF inserting THEN
                v_inserted_documents_counter := v_inserted_documents_counter + 1;
                v_inserted_documents_id(v_inserted_documents_counter) := v_new_document_id;
            ELSE
                IF NOT v_updated_documents_id.EXISTS(v_new_document_id) THEN
                    v_updated_documents_counter := v_updated_documents_counter + 1;
                    v_updated_documents_id(v_updated_documents_counter) := v_new_document_id;
                END IF;
          END IF;
    END BEFORE EACH ROW;

    AFTER STATEMENT IS
        BEGIN   

            FOR i in 1 .. v_inserted_documents_id.count LOOP
                UPDATE documents
                SET record_timestamp = v_timestamp,
                timestamp_ = v_timestamp,
                record_user_id = v_user || ' by insert trigger',
                user_id = v_user || ' by insert trigger'
                WHERE document_id = v_inserted_documents_id(i);
                dbms_output.put_line('INSERT: Trigger fired! Fields: Record Timestamp and Record User ID have been updated!');

            END LOOP;

            FOR i in 1 .. v_updated_documents_id.count LOOP
                UPDATE documents
                SET timestamp_ = v_timestamp,
                user_id = v_user || ' by update trigger'
                WHERE document_id = v_updated_documents_id(i);
                dbms_output.put_line('UPDATE: Trigger fired! Fields: Timestamp and User ID have been updated!');
            END LOOP;

            --dbms_output.put_line(v_inserted_documents_counter || ' record(s) inserted in table.');
            --dbms_output.put_line(v_updated_documents_counter || ' record(s) updated in table.');

    END AFTER STATEMENT;
END;

/
ALTER TRIGGER "MY_TRIGGER" ENABLE;
