--------------------------------------------------------
--  DDL for Package Body TESTER_PCKG
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE PACKAGE BODY "TESTER_PCKG" AS

     v_usr    VARCHAR2(30) := 'default';
     v_tstmp  TIMESTAMP(9) := to_timestamp('01-01-2000 00:00', 'MM-DD-YYYY HH24:MI:SS');

     PROCEDURE create_entries AS
     BEGIN
          DELETE FROM documents;
          create_single_entry(1, 'My First Document', '1x Important To Me');
          create_single_entry(2, 'My Second Document', '2x Important To Me');
          create_single_entry(3, 'My Third Document', NULL);
          create_single_entry(4, 'My Fourht Document', '4x Important To Me');
          create_single_entry(5, 'My Fifth Document', '5x Important To Me');
          create_single_entry(6, 'My Sixth Document', '6x Important To Me');
          create_single_entry(7, 'My Seventh Document', '7x Important To Me');
          create_single_entry(8, 'My Eight Document', '8x Important To Me');
          create_single_entry(9, 'My Nineth Document', '9x Important To Me');
          create_single_entry(10, 'My Tenth Document', '10x Important To Me');
     END create_entries;

    --Creation of single entry. Record Timestamp, Timestamp, Record User Id and User Id have default values
     PROCEDURE create_single_entry (
          doc_id           NUMBER,
          doc_name         IN  VARCHAR2,
          doc_description  IN  VARCHAR2
     ) AS
     BEGIN
          INSERT INTO documents (
               document_id,
               document_name,
               document_description,
               record_timestamp,
               timestamp_,
               record_user_id,
               user_id
          ) VALUES (
               doc_id,
               doc_name,
               doc_description,
               v_tstmp,
               v_tstmp,
               v_usr,
               v_usr
          );
     END create_single_entry;

     PROCEDURE update_table AS
     BEGIN
          update_single_entry(1, 'My Second Document', 'Again Important To Me');
     END update_table;

     PROCEDURE update_single_entry (
          doc_id           NUMBER,
          doc_name         IN  VARCHAR2,
          doc_description  IN  VARCHAR2
     ) AS
     BEGIN
          UPDATE documents
          SET
               document_id = doc_id,
               document_name = doc_name,
               document_description = doc_description
          WHERE
               document_id = doc_id;
     END;

END tester_pckg;



/
