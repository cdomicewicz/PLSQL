--------------------------------------------------------
--  DDL for Package Body MY_PACKAGE
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE PACKAGE BODY "MY_PACKAGE" AS

  FUNCTION validate_pesel (pesel IN VARCHAR2) RETURN BOOLEAN AS
    TYPE T_WEIGHTS IS VARRAY(11) OF SIMPLE_INTEGER;
    --Coefficents to calculate control number
    vt_Weights t_weights := t_weights(1, 3, 7, 9, 1, 3, 7,9,1,3,1);
    v_status VARCHAR(30) := 'incorrect';
    vn_checksum SIMPLE_INTEGER := 0;
    v_num NUMBER;
    v_len NUMBER;

BEGIN
    /*Pesel has to have eleven characters. 
    When it's true if pesel cannot be coverted to a integer exception will be thrown. 
    There could be also a method to validate, characters, length etc. */

    v_num := TO_NUMBER(PESEL);
    v_len  := LENGTH(PESEL);

    IF v_len = 11 THEN
        FOR i IN 1..vt_Weights.COUNT
            LOOP
                --Control number is calculated here
                vn_checksum := vn_checksum + TO_NUMBER(SUBSTR( PESEL, i,1)) * vt_Weights(i);
            END LOOP;
        --If there is no reminder, control number is correct. In any other case function will return false
        IF MOD(vn_checksum, 10) = 0 THEN
          v_status := 'correct';
          DBMS_OUTPUT.PUT_LINE('Control number: ' || vn_checksum || '.');
          DBMS_OUTPUT.PUT_LINE('PESEL: ' || PESEL || ' is ' || v_status ||'.');
          RETURN TRUE;
        END IF;
          DBMS_OUTPUT.PUT_LINE('Control number: ' || vn_checksum || '.');
    ELSE
        DBMS_OUTPUT.PUT_LINE('PESEL: ' || PESEL || ' is ' || v_status || '.');
    RETURN FALSE;
    END IF;
    DBMS_OUTPUT.PUT_LINE('PESEL: ' || PESEL || ' is ' || v_status || '.');
  RETURN FALSE;
EXCEPTION
WHEN VALUE_ERROR THEN
  DBMS_OUTPUT.PUT_LINE('PESEL: ' || PESEL || ' is ' || v_status || '.');
  RETURN FALSE;
  END validate_pesel;

PROCEDURE print_documents IS
CURSOR C_CURSOR IS SELECT * FROM DOCUMENTS;  
BEGIN 
    FOR R_DESC IN C_CURSOR LOOP
        IF R_DESC.DOCUMENT_DESCRIPTION IS NOT NULL THEN 
          DBMS_OUTPUT.PUT_LINE(R_DESC.DOCUMENT_DESCRIPTION);
        ELSE 
          DBMS_OUTPUT.PUT_LINE('No Description');
        END IF;
    END LOOP;
  END print_documents;
END MY_PACKAGE;



/
