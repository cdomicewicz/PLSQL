SET SERVEROUTPUT ON;
DECLARE
v_bool BOOLEAN;
BEGIN
--Creation of some example records (10 entries). Trigger will display information about detected operation.
DBMS_OUTPUT.PUT_LINE('CREATE ENTRIES:');
tester_pckg.create_entries;
DBMS_OUTPUT.PUT_LINE(chr(10));
--Creation of single entry. Trigger runs and inserts four fields: Record Timestamp, Timestamp, Record User Id and User Id. I decided to fill Timestamp and User Id by trigger on insert..
DBMS_OUTPUT.PUT_LINE('CREATE SINGLE ENTRY:');
tester_pckg.create_single_entry(11, 'My Eleventh Document', '11x Important To Me');
DBMS_OUTPUT.PUT_LINE(chr(10));
--Update of single entry. Trigger runs and updates only two fields: Timestamp and User Id
DBMS_OUTPUT.PUT_LINE('UPDATE SINGLE ENTRY:');
tester_pckg.update_single_entry(2, 'My Updated Second Document', 'Simply Updated');
DBMS_OUTPUT.PUT_LINE(chr(10));
--Procedure that prints all document descriptions. If it's null, then the procuderes prints "No Description".
DBMS_OUTPUT.PUT_LINE('PRINT DOCUMENTS:');
my_package.print_documents;
DBMS_OUTPUT.PUT_LINE(chr(10));
--Function that checks if pesel number is correct. Function returns true or false so it must be assigned to variable
DBMS_OUTPUT.PUT_LINE('VALIDATE PESEL:');
v_bool := my_package.validate_pesel('88031308313');
END;